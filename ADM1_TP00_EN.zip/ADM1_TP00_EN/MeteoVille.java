public class MeteoVille {
    private String ville;
    private int vV;
    private int hL;
    private int mL;
    private int hC;
    private int mC;
    private String ciel;
    public MeteoVille(String ville, int vV, int hL, int mL, int hC, int mC, String ciel) {
        this.ville = ville;
        this.vV = vV;
        this.hL = hL;
        this.mL = mL;
        this.hC = hC;
        this.mC = mC;
        this.ciel = ciel;
    }
    public String getVille() {        return ville;    }
    public int getvV() {        return vV;    }
    public int gethL() {        return hL;    }
    public int getmL() {        return mL;    }
    public int gethC() {        return hC;    }
    public int getmC() {        return mC;    }
    public String getCiel() {        return ciel;    }
    public String getLongueurJour() {
        String longJour = "";
        int lm = (hC * 60 + mC) - (hL * 60 + mL);
        int nbHeure = lm / 60;
        int nbMinute = lm % 60;
        longJour = nbHeure + " H" + " " + nbMinute + " Min";
        return longJour;
    }
    public String getEtatMer() {
        switch (vV) {
            case 15:
                return "Calme";
            case 30:
                return "Agitée";

            case 60:
                return "Très Agitée";
        }
        return "";
    }
    @Override
    public String toString() {
        return ville + " - V: " + vV + "Km/h" + " - Ciel " + ciel;
    }
}

