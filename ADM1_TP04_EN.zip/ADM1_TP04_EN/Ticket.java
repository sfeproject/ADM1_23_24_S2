package com.ticket;

public class Ticket {
    private static final int[][] TARIF_VEHICULE={{5,10,15},{5,15,20}};
    private static final int TARIF_PASSAGER = 1;
    private String matricule;
    private String type;        // Voiture-Camion-Bus
    private int nbPassager;
    private boolean poidsLeger;  // true: leger   false:lourd
    private int remise;     // de 0% à 100%


    public Ticket(String matricule, String type, int nbPassager, boolean poidsLeger, int remise) {
        this.matricule = matricule;
        this.type = type;
        this.nbPassager = nbPassager;
        this.poidsLeger = poidsLeger;
        this.remise = remise;
    }

    public String getMatricule() {
        return matricule;
    }

    public String getType() {
        return type;
    }

    public int getNbPassager() {
        return nbPassager;
    }

    public boolean isPoidLeger() {
        return poidsLeger;
    }

    public int getRemise() {
        return remise;
    }

    public int getPrix() {
        int iT=0;
        int iL=0;
        if(type.equalsIgnoreCase("Voiture"))
            iT=0;
        else if(type.equalsIgnoreCase("Camion"))
            iT=1;
        else
            iT=2;
        if(poidsLeger)
            iL=0;
        else
            iL=1;
        return (TARIF_VEHICULE[iL][iT]+TARIF_PASSAGER*nbPassager)*(100-remise)/100;
    }
    public String getStrPoids(){
        if (poidsLeger)
            return "Léger";
        else
            return "Lourd";
    }
    @Override
    public String toString() {

        return matricule + "{" +
                type +
                "- " + nbPassager + "P"+
                "- "+ getPrix() +"DT"+
                '}';
    }
}
