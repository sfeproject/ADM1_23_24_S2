package com.location;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private static final int ACTION_AJOUT = 1;
    private EditText edA;
    private EditText edPJ;
    private Button btnA;
    private Button btnST;
    private ListView lstL;
    private ArrayAdapter<Location> adpL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }
    private void init(){
        edA=findViewById(R.id.edA);
        edPJ=findViewById(R.id.edPJ);
        btnA=findViewById(R.id.btnA);
        btnST=findViewById(R.id.btnST);
        lstL=findViewById(R.id.lstL);
      
        
    }

    

}