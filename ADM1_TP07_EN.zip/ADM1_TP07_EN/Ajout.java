package com.location;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Ajout extends AppCompatActivity {
    private EditText edP;
    private EditText edV;
    private EditText edNbJ;
    private Button btnV;
    private Button btnA;


  

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajout);
        init();
    }
    private void init(){
        edP=findViewById(R.id.edP);
        edV=findViewById(R.id.edV);
        edNbJ=findViewById(R.id.edNbJ);
        btnV=findViewById(R.id.btnV);
        btnA=findViewById(R.id.btnA1);
        
    }

  

}