package com.location;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class DetailLocation extends AppCompatActivity {
    private TextView tvD;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_loc);
        init();
    }
    private void init(){
        tvD=findViewById(R.id.tvD);
       
    }

}