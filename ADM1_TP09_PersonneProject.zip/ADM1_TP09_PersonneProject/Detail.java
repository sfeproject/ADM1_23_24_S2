package com.complexe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

public class Detail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        initGraphique();
    }

    private void initGraphique() {


            Personne p = getIntent().getParcelableExtra("personne");


            if(p!=null){
                Toast.makeText(this, "Nom:"+p.getNom()+"inscrit:"+p.isInscrit(), Toast.LENGTH_LONG).show();
            }


    }
}