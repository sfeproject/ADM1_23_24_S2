package com.complexe;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import java.io.Serializable;

public class Personne implements Parcelable {
    private String nom;
    private String prenom;
    private int age;
    private boolean inscrit;
    public Personne(String nom, String prenom, int age, boolean inscrit) {
        this.nom = nom;
        this.prenom = prenom;
        this.age = age;
        this.inscrit = inscrit;
    }

    protected Personne(Parcel in) {
        nom = in.readString();
        prenom = in.readString();
        age = in.readInt();
        inscrit = in.readByte() != 0;
    }

    public static final Creator<Personne> CREATOR = new Creator<Personne>() {
        @Override
        public Personne createFromParcel(Parcel in) {
            return new Personne(in);
        }

        @Override
        public Personne[] newArray(int size) {
            return new Personne[size];
        }
    };

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public int getAge() {
        return age;
    }

    public boolean isInscrit() {
        return inscrit;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeString(nom);
        dest.writeString(prenom);
        dest.writeInt(age);
        dest.writeByte((byte) (inscrit ? 1 : 0));
    }
}
