package com.complexe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.SeekBar;

public class MainActivity extends AppCompatActivity {
    private EditText edNom;
    private EditText edPrenom;
    private SeekBar seekAge;
    private CheckBox chInscrit;
    private Button btnEnregistrer;
    private Button btnPasser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initGraphique();
    }

    private void initGraphique() {
        edNom=findViewById(R.id.edNom);
        edPrenom=findViewById(R.id.edPrenom);
        seekAge=findViewById(R.id.seekAge);
        chInscrit=findViewById(R.id.chInscrit);
        btnEnregistrer=findViewById(R.id.btnEnregistrer);
        btnPasser=findViewById(R.id.btnPasser);
        ajouterEcouteurs();
        recuperer();
    }

    private void recuperer() {
        SharedPreferences p=getSharedPreferences("Personne", Context.MODE_PRIVATE);
        edNom.setText(p.getString("nom",""));
        edPrenom.setText(p.getString("prenom",""));
        seekAge.setProgress(p.getInt("age",0));
        chInscrit.setChecked(p.getBoolean("inscrit",false));
    }

    private void ajouterEcouteurs() {
        btnEnregistrer.setOnClickListener(v -> enregistrer());
        btnPasser.setOnClickListener(v -> passer());
    }

    private void passer() {
        Intent i=new Intent(this,Detail.class);
        Personne p=new Personne(edNom.getText().toString(),edPrenom.getText().toString(),seekAge.getProgress(),chInscrit.isChecked());

        i.putExtra("personne",p);



        startActivity(i);

    }

    private void enregistrer() {
        SharedPreferences p=getSharedPreferences("Personne", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed=p.edit();
        ed.putString("nom",edNom.getText().toString());
        ed.putString("prenom",edPrenom.getText().toString());
        ed.putInt("age",seekAge.getProgress());
        ed.putBoolean("inscrit",chInscrit.isChecked());
        ed.commit();
    }
}