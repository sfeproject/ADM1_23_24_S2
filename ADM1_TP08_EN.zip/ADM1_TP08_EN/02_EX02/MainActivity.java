package car.com.appeltel;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity {
  private EditText edNumero;
  private EditText edCorps;
  private Button btnEnvoyer;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    init();
  }
  private void init() {
	ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.SEND_SMS, Manifest.permission.READ_PHONE_STATE }, 101);

    edNumero=(EditText) findViewById(R.id.edNumero);
    edCorps=(EditText) findViewById(R.id.edCorps);
    btnEnvoyer=(Button) findViewById(R.id.btnEnvoyer);
    ajouterEcouteur();
  }
  private void ajouterEcouteur() {
  
    
  }
 
  
}

